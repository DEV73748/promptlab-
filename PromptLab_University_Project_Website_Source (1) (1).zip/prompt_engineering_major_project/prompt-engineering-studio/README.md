# PromptLab — AI Prompt Engineering Studio

A university major-project starter: a responsive prompt engineering workspace built with Next.js, TypeScript, Tailwind CSS, and the Vercel AI SDK.

## Features
- Prompt composer and streamed model responses
- Prompt optimization endpoint
- Provider switcher: OpenAI, Google Gemini, Anthropic Claude
- Bring Your Own API Key (BYOK)
- System instruction editor
- Prompt templates, session history, and in-session saved prompts
- Responsive dashboard UI

## Requirements
- Node.js 18.17+ (Node 20 LTS recommended)
- An API key from at least one supported provider

## Run locally
1. Install dependencies: `npm install`
2. Copy `.env.example` to `.env.local` if you want to use server-managed keys.
3. Add one or more provider keys to `.env.local`.
4. Start the development server: `npm run dev`
5. Open http://localhost:3000

## Bring Your Own Key
You can paste a key in the Model Configuration panel. The key is included only in the request to your own Next.js API route and is not written to localStorage or cookies by this starter. For a public deployment, prefer server-managed keys, authentication, rate limits, request quotas, and a secrets manager. Do not log request bodies or expose provider keys in client-side environment variables.

## Deploy to Vercel
1. Push the project to a private Git repository.
2. Import it into Vercel.
3. Add provider keys under Project → Settings → Environment Variables.
4. Deploy. The API routes execute server-side.

## Important production hardening
This is a functional academic starter, not a fully hardened multi-user SaaS. Before public use, add authentication, abuse prevention/rate limiting, usage limits, privacy disclosures, server-side key management, and persistent database storage. Never commit real API keys.

## Project structure
- `app/page.tsx` — dashboard, prompt composer, templates, and history
- `app/api/chat/route.ts` — streamed chat endpoint using Vercel AI SDK
- `app/api/optimize/route.ts` — prompt improvement endpoint
- `app/globals.css` — responsive design system
- `.env.example` — server-side environment variable template

## Academic customization
Replace the sample project identity, team members, guide, institution, screenshots, and test observations in the accompanying presentation before submission.
