"use client";

import { useMemo, useState } from "react";
import { Activity, ArrowDown, ArrowUpRight, Bot, Check, ChevronDown, CircleHelp, Copy, Cpu, KeyRound, Layers3, LockKeyhole, Menu, MessageSquareText, PanelLeft, Play, Plus, Save, Sparkles, WandSparkles, X } from "lucide-react";

type ChatMessage = { role: "user" | "assistant"; content: string };
const templates = [
  { title: "Explain a concept", tag: "Education", prompt: "Act as an expert teacher. Explain [TOPIC] to a beginner using a simple analogy, a step-by-step breakdown, and three practical examples. End with a short recap." },
  { title: "Write professional email", tag: "Writing", prompt: "Act as a professional communication specialist. Draft an email to [RECIPIENT] about [PURPOSE]. Use a clear subject, concise paragraphs, a courteous tone, and one specific call to action." },
  { title: "Debug code", tag: "Development", prompt: "Act as a senior software engineer. Review the following code, identify the root cause of the issue, explain why it happens, and provide a corrected solution with a concise explanation: [CODE]" },
  { title: "Research assistant", tag: "Research", prompt: "Act as a research assistant. Investigate [TOPIC], distinguish established facts from uncertainty, organize findings under clear headings, and provide a concise list of follow-up questions." }
];

export default function Home() {
  const [provider, setProvider] = useState("openai");
  const [model, setModel] = useState("gpt-4o-mini");
  const [apiKey, setApiKey] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [systemPrompt, setSystemPrompt] = useState("You are a helpful assistant. Be accurate, clear, and structured.");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [busy, setBusy] = useState(false);
  const [optimizing, setOptimizing] = useState(false);
  const [notice, setNotice] = useState("");
  const [activeTab, setActiveTab] = useState("playground");
  const [saved, setSaved] = useState<string[]>([]);
  const [mobileNav, setMobileNav] = useState(false);

  const modelOptions = useMemo(() => provider === "google"
    ? [{ value: "gemini-2.0-flash", label: "Gemini 2.0 Flash" }, { value: "gemini-1.5-pro", label: "Gemini 1.5 Pro" }]
    : provider === "anthropic"
    ? [{ value: "claude-3-5-haiku-latest", label: "Claude 3.5 Haiku" }, { value: "claude-3-5-sonnet-latest", label: "Claude 3.5 Sonnet" }]
    : [{ value: "gpt-4o-mini", label: "GPT-4o mini" }, { value: "gpt-4o", label: "GPT-4o" }], [provider]);

  function changeProvider(value: string) {
    setProvider(value);
    setModel(value === "google" ? "gemini-2.0-flash" : value === "anthropic" ? "claude-3-5-haiku-latest" : "gpt-4o-mini");
    setNotice("");
  }

  async function runPrompt() {
    if (!prompt.trim() || busy) return;
    const next = [...messages, { role: "user" as const, content: prompt }];
    setMessages(next); setPrompt(""); setBusy(true); setNotice("");
    try {
      const response = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages: next, provider, model, apiKey, systemPrompt }) });
      if (!response.ok) {
        const data = await response.json(); throw new Error(data.error || "Request failed.");
      }
      const reader = response.body?.getReader();
      if (!reader) throw new Error("No response stream received.");
      const decoder = new TextDecoder();
      let answer = "";
      setMessages([...next, { role: "assistant", content: "" }]);
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        answer += decoder.decode(value, { stream: true });
        setMessages([...next, { role: "assistant", content: answer }]);
      }
    } catch (e) {
      setNotice(e instanceof Error ? e.message : "Something went wrong.");
      setMessages(next);
    } finally { setBusy(false); }
  }

  async function optimizePrompt() {
    if (!prompt.trim() || optimizing) return;
    setOptimizing(true); setNotice("");
    try {
      const response = await fetch("/api/optimize", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ prompt, provider, model, apiKey }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Optimization failed.");
      setPrompt(data.optimizedPrompt);
    } catch (e) { setNotice(e instanceof Error ? e.message : "Optimization failed."); }
    finally { setOptimizing(false); }
  }

  async function copyText(text: string) {
    try { await navigator.clipboard.writeText(text); setNotice("Copied to clipboard."); }
    catch { setNotice("Clipboard access is unavailable in this browser."); }
  }

  function savePrompt() {
    if (!prompt.trim()) return;
    setSaved(prev => [prompt, ...prev.filter(p => p !== prompt)]);
    setNotice("Prompt saved in this session.");
  }

  return <main className="app-shell">
    <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
      <div className="brand"><div className="brand-mark"><Sparkles size={19}/></div><span>prompt<span className="brand-light">lab</span></span><button className="mobile-close" onClick={() => setMobileNav(false)}><X size={18}/></button></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>
        <button className={`nav-item ${activeTab === "playground" ? "active" : ""}`} onClick={() => {setActiveTab("playground");setMobileNav(false)}}><PanelLeft size={17}/> Playground <span className="nav-dot"/></button>
        <button className={`nav-item ${activeTab === "library" ? "active" : ""}`} onClick={() => {setActiveTab("library");setMobileNav(false)}}><Layers3 size={17}/> Prompt library</button>
        <button className={`nav-item ${activeTab === "history" ? "active" : ""}`} onClick={() => {setActiveTab("history");setMobileNav(false)}}><Activity size={17}/> Session history</button>
      </nav>
      <div className="sidebar-bottom"><div className="secure-card"><div className="secure-icon"><LockKeyhole size={16}/></div><strong>Your keys, your control</strong><p>Keys are sent only with your request and are not saved by this demo.</p></div><div className="profile"><div className="avatar">PS</div><div><strong>Project Studio</strong><span>University edition</span></div><ChevronDown size={15}/></div></div>
    </aside>
    {mobileNav && <div className="scrim" onClick={() => setMobileNav(false)}/>}
    <section className="main-area">
      <header className="topbar"><button className="mobile-menu" onClick={() => setMobileNav(true)}><Menu size={19}/></button><div className="breadcrumb">Workspace <span>/</span> <b>{activeTab === "playground" ? "Playground" : activeTab === "library" ? "Prompt library" : "Session history"}</b></div><div className="top-actions"><span className="status-pill"><span/> All systems ready</span><button className="help-btn" title="Help"><CircleHelp size={18}/></button></div></header>
      {activeTab === "playground" ? <div className="content">
        <div className="page-heading"><div><div className="eyebrow">AI WORKSPACE <span>·</span> PROMPT ENGINEERING</div><h1>Build better prompts.</h1><p>Design, refine, and test instructions across leading AI models.</p></div><div className="heading-chip"><WandSparkles size={15}/> Prompt engineering studio</div></div>
        <div className="metrics"><div className="metric-card"><div className="metric-icon violet"><MessageSquareText size={17}/></div><div><span>Prompts this session</span><strong>{messages.filter(m => m.role === "user").length}</strong></div></div><div className="metric-card"><div className="metric-icon blue"><Cpu size={17}/></div><div><span>Active provider</span><strong className="metric-provider">{provider === "google" ? "Google Gemini" : provider === "anthropic" ? "Anthropic Claude" : "OpenAI"}</strong></div></div><div className="metric-card"><div className="metric-icon green"><Save size={17}/></div><div><span>Saved prompts</span><strong>{saved.length}</strong></div></div></div>
        <div className="workspace-grid">
          <div className="left-column">
            <section className="panel prompt-panel">
              <div className="panel-heading"><div><span className="step">01</span><div><h2>Prompt composer</h2><p>Write your instruction or start from a template.</p></div></div><span className="live-label"><span/> EDITOR</span></div>
              <div className="prompt-toolbar"><span><span className="tiny-dot"/> YOUR PROMPT</span><div><button onClick={() => setPrompt("")}>Clear</button><button onClick={savePrompt}><Save size={14}/> Save</button></div></div>
              <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder={"You are an expert...\n\nDescribe the task, provide context, define constraints, and specify the desired output."}/>
              <div className="composer-footer"><span>{prompt.length} characters</span><div className="composer-actions"><button className="secondary-btn" onClick={optimizePrompt} disabled={!prompt.trim() || optimizing}><WandSparkles size={15}/>{optimizing ? "Optimizing..." : "Optimize prompt"}</button><button className="primary-btn" onClick={runPrompt} disabled={!prompt.trim() || busy}><Play size={14} fill="currentColor"/>{busy ? "Running..." : "Run prompt"} <ArrowUpRight size={14}/></button></div></div>
            </section>
            <section className="panel response-panel">
              <div className="panel-heading"><div><span className="step">02</span><div><h2>Model response</h2><p>Generated output appears here in real time.</p></div></div><button className="icon-btn" onClick={() => copyText(messages.filter(m => m.role === "assistant").map(m => m.content).join("\n\n"))} title="Copy response"><Copy size={15}/></button></div>
              <div className="response-body">{messages.length ? messages.map((m,i) => <div className={`message ${m.role}`} key={i}><div className="message-label">{m.role === "user" ? "YOU" : <><Sparkles size={12}/> AI RESPONSE</>}</div><p>{m.content || (busy ? "Thinking…" : "")}</p></div>) : <div className="empty-response"><div className="empty-orb"><Bot size={25}/></div><strong>Your output will appear here</strong><p>Write a prompt above, choose a model, and run it to see the response.</p></div>}</div>
            </section>
          </div>
          <div className="right-column">
            <section className="panel config-panel"><div className="panel-heading compact"><div><span className="step">03</span><div><h2>Model configuration</h2><p>Choose your AI provider.</p></div></div></div>
              <label className="field-label">AI PROVIDER</label><div className="provider-options">
                <button className={provider === "openai" ? "provider active-provider" : "provider"} onClick={() => changeProvider("openai")}><span className="provider-logo openai-logo">◎</span><span>OpenAI</span>{provider === "openai" && <Check size={14}/>}</button>
                <button className={provider === "google" ? "provider active-provider" : "provider"} onClick={() => changeProvider("google")}><span className="provider-logo google-logo">✦</span><span>Gemini</span>{provider === "google" && <Check size={14}/>}</button>
                <button className={provider === "anthropic" ? "provider active-provider" : "provider"} onClick={() => changeProvider("anthropic")}><span className="provider-logo claude-logo">✳</span><span>Claude</span>{provider === "anthropic" && <Check size={14}/>}</button>
              </div>
              <label className="field-label">MODEL</label><select value={model} onChange={e => setModel(e.target.value)}>{modelOptions.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}</select>
              <div className="key-label-row"><label className="field-label">API KEY <span>· OPTIONAL IF SERVER KEY SET</span></label><KeyRound size={14}/></div>
              <div className="key-input"><input type={showKey ? "text" : "password"} value={apiKey} onChange={e => setApiKey(e.target.value)} placeholder="Paste your provider key"/><button onClick={() => setShowKey(!showKey)}>{showKey ? "Hide" : "Show"}</button></div>
              <div className="key-note"><LockKeyhole size={13}/> Sent over HTTPS to your server route; never written to browser storage.</div>
              <div className="config-divider"/>
              <label className="field-label">SYSTEM INSTRUCTIONS</label><textarea className="system-input" value={systemPrompt} onChange={e => setSystemPrompt(e.target.value)} rows={3}/>
            </section>
            <section className="panel tips-panel"><div className="tips-title"><Sparkles size={16}/><strong>Prompting essentials</strong></div><div className="tip"><span>01</span><div><b>Give it a role</b><p>Define the expertise or perspective the AI should use.</p></div></div><div className="tip"><span>02</span><div><b>Add context</b><p>Include relevant background and audience details.</p></div></div><div className="tip"><span>03</span><div><b>Specify the output</b><p>Set format, length, tone, and success criteria.</p></div></div></section>
          </div>
        </div>
        {notice && <div className="toast" role="status">{notice}<button onClick={() => setNotice("")}><X size={14}/></button></div>}
      </div> : activeTab === "library" ? <div className="content"><div className="page-heading"><div><div className="eyebrow">WORKSPACE · RESOURCES</div><h1>Prompt library.</h1><p>Start with a proven structure, then make it your own.</p></div></div><div className="template-grid">{templates.map(t => <button className="template-card" key={t.title} onClick={() => {setPrompt(t.prompt);setActiveTab("playground");}}><span className="template-tag">{t.tag}</span><strong>{t.title}</strong><p>{t.prompt}</p><span className="use-template">Use template <ArrowUpRight size={14}/></span></button>)}</div><div className="saved-section"><h2>Your saved prompts <span>{saved.length}</span></h2>{saved.length ? saved.map((s,i)=><div className="saved-row" key={i}><p>{s}</p><button onClick={()=>{setPrompt(s);setActiveTab("playground")}}>Open <ArrowUpRight size={14}/></button></div>) : <p className="muted">Prompts you save in this session will appear here.</p>}</div></div> : <div className="content"><div className="page-heading"><div><div className="eyebrow">WORKSPACE · ACTIVITY</div><h1>Session history.</h1><p>Review the conversation from your current browser session.</p></div></div><section className="panel history-panel">{messages.length ? messages.map((m,i)=><div className="history-row" key={i}><span className={`history-bullet ${m.role}`}/><div><b>{m.role === "user" ? "Prompt submitted" : "Model response"}</b><p>{m.content || "Generating…"}</p></div><span className="history-time">This session</span></div>) : <div className="empty-response"><div className="empty-orb"><Activity size={23}/></div><strong>No activity yet</strong><p>Your prompt runs will be listed here.</p></div>}</section></div>}
      <footer className="footer"><span>© 2026 PromptLab · University Major Project</span><span>Built with Next.js + Vercel AI SDK</span></footer>
    </section>
  </main>;
}