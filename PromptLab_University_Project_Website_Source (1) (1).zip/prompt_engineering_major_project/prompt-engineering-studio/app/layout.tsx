import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PromptLab — AI Prompt Engineering Studio",
  description: "Design, optimize, test and compare prompts across AI providers."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}