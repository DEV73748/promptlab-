import { NextRequest } from "next/server";
import { streamText } from "ai";
import { createOpenAI } from "@ai-sdk/openai";
import { createGoogleGenerativeAI } from "@ai-sdk/google";
import { createAnthropic } from "@ai-sdk/anthropic";

export const runtime = "nodejs";

type Provider = "openai" | "google" | "anthropic";

export async function POST(req: NextRequest) {
  try {
    const { messages, provider = "openai", model, apiKey, systemPrompt } = await req.json();
    const selected = provider as Provider;
    const key = (typeof apiKey === "string" && apiKey.trim()) || keyFromEnvironment(selected);
    if (!key) return Response.json({ error: `Add an API key for ${selected} to run this model.` }, { status: 400 });

    let modelInstance;
    if (selected === "google") {
      const google = createGoogleGenerativeAI({ apiKey: key });
      modelInstance = google(model || "gemini-2.0-flash");
    } else if (selected === "anthropic") {
      const anthropic = createAnthropic({ apiKey: key });
      modelInstance = anthropic(model || "claude-3-5-haiku-latest");
    } else {
      const openai = createOpenAI({ apiKey: key });
      modelInstance = openai(model || "gpt-4o-mini");
    }

    const result = streamText({
      model: modelInstance,
      messages,
      system: systemPrompt || "You are a helpful assistant. Be accurate, clear, and structured."
    });
    return result.toTextStreamResponse();
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unexpected server error.";
    return Response.json({ error: message }, { status: 500 });
  }
}

function keyFromEnvironment(provider: Provider) {
  if (provider === "google") return process.env.GOOGLE_GENERATIVE_AI_API_KEY;
  if (provider === "anthropic") return process.env.ANTHROPIC_API_KEY;
  return process.env.OPENAI_API_KEY;
}