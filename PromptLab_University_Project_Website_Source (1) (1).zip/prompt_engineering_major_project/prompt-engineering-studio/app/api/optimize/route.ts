import { NextRequest } from "next/server";
import { generateText } from "ai";
import { createOpenAI } from "@ai-sdk/openai";
import { createGoogleGenerativeAI } from "@ai-sdk/google";
import { createAnthropic } from "@ai-sdk/anthropic";

export async function POST(req: NextRequest) {
  try {
    const { prompt, provider = "openai", model, apiKey } = await req.json();
    if (!prompt || typeof prompt !== "string") return Response.json({ error: "Enter a prompt to optimize." }, { status: 400 });
    const key = (typeof apiKey === "string" && apiKey.trim()) || envKey(provider);
    if (!key) return Response.json({ error: `Add an API key for ${provider} to optimize prompts.` }, { status: 400 });

    const modelInstance = provider === "google"
      ? createGoogleGenerativeAI({ apiKey: key })(model || "gemini-2.0-flash")
      : provider === "anthropic"
      ? createAnthropic({ apiKey: key })(model || "claude-3-5-haiku-latest")
      : createOpenAI({ apiKey: key })(model || "gpt-4o-mini");

    const result = await generateText({
      model: modelInstance,
      system: "You are an expert prompt engineer. Rewrite the user's prompt to be clear, specific, contextual, and testable. Preserve the original intent. Add role, objective, relevant context, constraints, and a clear output format when appropriate. Return only the improved prompt, without commentary.",
      prompt
    });
    return Response.json({ optimizedPrompt: result.text });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Optimization failed." }, { status: 500 });
  }
}

function envKey(provider: string) {
  if (provider === "google") return process.env.GOOGLE_GENERATIVE_AI_API_KEY;
  if (provider === "anthropic") return process.env.ANTHROPIC_API_KEY;
  return process.env.OPENAI_API_KEY;
}